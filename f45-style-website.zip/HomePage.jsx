import React from "react";
import { Button } from "./components/ui/button";
import { Card, CardContent } from "./components/ui/card";
import { Input } from "./components/ui/input";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      <section className="bg-[url('/hero-image.jpg')] bg-cover bg-center py-20 text-center text-white">
        <div className="max-w-4xl mx-auto px-4">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            Functional Fitness. Team Training. Life Changing.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-lg md:text-xl mb-8"
          >
            Join our community and transform your fitness experience.
          </motion.p>
          <Button className="bg-blue-600 text-white px-6 py-3 text-lg rounded-2xl shadow-xl">
            Start Your Trial
          </Button>
        </div>
      </section>

      <section id="trial" className="py-20 bg-gray-100">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Claim Your Trial</h2>
          <p className="text-lg mb-10">
            Fill out the form below and get started with a special trial offer at our studio!
          </p>
          <Card className="p-6 shadow-lg">
            <CardContent>
              <form className="space-y-4">
                <Input type="text" placeholder="Full Name" required />
                <Input type="email" placeholder="Email Address" required />
                <Input type="tel" placeholder="Phone Number" required />
                <Button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-xl text-lg">
                  Submit
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
